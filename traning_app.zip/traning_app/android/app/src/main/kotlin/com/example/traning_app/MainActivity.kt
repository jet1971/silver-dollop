package com.example.traning_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
